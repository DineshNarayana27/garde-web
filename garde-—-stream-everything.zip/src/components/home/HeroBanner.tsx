import { useRouter } from 'next/navigation';
import { Play, Plus, Info, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { useStore } from '../../store/useStore';
import { Content } from '../../types';

interface HeroBannerProps {
  content?: Content | null;
}

export function HeroBanner({ content }: HeroBannerProps) {
  const router = useRouter();
  const { addToList, removeFromList, isInList } = useStore();
  
  if (!content) {
    return (
      <div className="relative h-[92vh] w-full overflow-hidden bg-background shimmer">
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>
    );
  }

  const inList = isInList(content.id);

  const handleToggleList = () => {
    if (inList) {
      removeFromList(content.id);
    } else {
      addToList(content);
    }
  };

  return (
    <div className="relative h-[92vh] w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${content.backdrop_url})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/* Noise Overlay */}
      <div className="noise-overlay opacity-10" />

      {/* Content */}
      <div className="relative flex h-full max-w-7xl flex-col justify-end pb-32 px-4 md:px-8 lg:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <div className="mb-6">
            <span className="rounded-md bg-accent-indigo px-3 py-1.5 text-[10px] font-black uppercase tracking-[2px] text-white shadow-lg shadow-accent-indigo/30">
              FEATURED FILM
            </span>
          </div>

          <h1 className="mb-6 font-sans text-6xl font-black md:text-8xl lg:text-9xl tracking-tighter leading-[0.85] text-white">
            {content.title}
          </h1>

          <div className="mb-8 flex items-center gap-4 text-[11px] font-bold uppercase tracking-widest">
            <span className="flex items-center gap-1 text-gold">
              ★ {content.rating}
            </span>
            <span className="text-secondary-text">·</span>
            <span className="text-secondary-text">{content.year}</span>
            <span className="text-secondary-text">·</span>
            {content.duration && <span className="text-secondary-text">{content.duration}</span>}
            <span className="text-secondary-text">·</span>
            <span className="text-accent-indigo">{content.type}</span>
          </div>

          <p className="mb-10 text-lg text-secondary-text line-clamp-3 font-medium leading-relaxed max-w-xl">
            {content.description}
          </p>

          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => router.push(`/watch/${content.id}`)}
              className="flex items-center gap-2 rounded-lg bg-accent-indigo px-10 py-4 font-bold text-white transition-all hover:bg-accent-indigo/90 hover:scale-105 active:scale-95 shadow-xl shadow-accent-indigo/20"
            >
              <Play size={18} fill="currentColor" />
              Watch Now
            </button>
            <button 
              onClick={handleToggleList}
              className="flex items-center gap-2 rounded-lg bg-white/10 border border-white/20 px-10 py-4 font-bold text-white backdrop-blur-md transition-all hover:bg-white/20 hover:scale-105 active:scale-95"
            >
              {inList ? <Check size={18} /> : <Plus size={18} />}
              {inList ? 'In Watchlist' : '+ Watchlist'}
            </button>
            <button 
              onClick={() => router.push(`/detail/${content.id}`)}
              className="flex items-center gap-2 rounded-lg px-8 py-4 font-bold text-secondary-text transition-all hover:text-white hover:scale-105 active:scale-95"
            >
              <Info size={18} />
              More Info
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
