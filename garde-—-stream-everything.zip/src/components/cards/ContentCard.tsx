import { useRouter } from 'next/navigation';
import { Star, Play, Plus, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { useStore } from '../../store/useStore';
import { Content } from '../../types';

interface ContentCardProps {
  content: Content;
}

export function ContentCard({ content }: ContentCardProps) {
  const router = useRouter();
  const { addToList, removeFromList, isInList } = useStore();
  const inList = isInList(content.id);

  const handleToggleList = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (inList) {
      removeFromList(content.id);
    } else {
      addToList(content);
    }
  };

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    router.push(`/watch/${content.id}`);
  };

  // Mocking some data for the new design system requirements
  const productionName = "Garde Originals"; // In a real app, this would come from content.production
  const isRising = content.view_count > 1000; // Mock logic for RISING badge
  const isNew = new Date(content.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000;

  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="group relative w-[180px] flex-shrink-0 cursor-pointer"
      onClick={() => router.push(`/detail/${content.id}`)}
    >
      {/* Poster Image */}
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl border border-border-custom bg-card shadow-lg transition-all duration-500 group-hover:border-accent-indigo/50 group-hover:shadow-2xl group-hover:shadow-accent-indigo/20">
        <img
          src={content.thumbnail_url}
          alt={content.title}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        
        {/* Noise Overlay */}
        <div className="noise-overlay opacity-0 group-hover:opacity-10 transition-opacity duration-500" />

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {isRising && (
            <div className="rounded bg-accent-green px-1.5 py-0.5 text-[8px] font-black text-white shadow-lg shadow-accent-green/30">
              RISING
            </div>
          )}
          {isNew && (
            <div className="rounded bg-accent-indigo px-1.5 py-0.5 text-[8px] font-black text-white shadow-lg shadow-accent-indigo/30">
              NEW
            </div>
          )}
        </div>

        {/* Hover Actions Overlay */}
        <div className="absolute inset-0 flex items-center justify-center gap-3 bg-black/60 opacity-0 transition-opacity duration-300 group-hover:opacity-100 backdrop-blur-[2px]">
          <button 
            onClick={handlePlay}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-accent-indigo text-white shadow-lg shadow-accent-indigo/30 transition-transform hover:scale-110 active:scale-95"
          >
            <Play size={18} fill="currentColor" />
          </button>
          <button 
            onClick={handleToggleList}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white border border-white/20 backdrop-blur-md transition-transform hover:scale-110 active:scale-95"
          >
            {inList ? <Check size={18} /> : <Plus size={18} />}
          </button>
        </div>
      </div>

      {/* Content Info */}
      <div className="mt-3 px-1">
        <h3 className="text-[13px] font-bold text-white line-clamp-1 group-hover:text-accent-indigo transition-colors">
          {content.title}
        </h3>
        <p className="mt-0.5 text-[10px] font-medium text-secondary-text uppercase tracking-wider">
          {productionName}
        </p>
        <div className="mt-1.5 flex items-center gap-1.5">
          <div className="flex items-center gap-0.5 text-gold">
            <Star size={10} fill="currentColor" />
            <span className="text-[10px] font-bold">{content.rating}</span>
          </div>
          <span className="text-[10px] text-secondary-text">·</span>
          <span className="text-[10px] text-secondary-text">{content.view_count} Screenings</span>
        </div>
      </div>
    </motion.div>
  );
}
