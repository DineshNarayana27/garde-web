/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  experimental: {
    allowedDevOrigins: ['ais-dev-vsmyglawbmgq7vw2zrkb73-16056577218.asia-southeast1.run.app', 'ais-pre-vsmyglawbmgq7vw2zrkb73-16056577218.asia-southeast1.run.app'],
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'picsum.photos',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
      },
    ],
  },
};

export default nextConfig;
