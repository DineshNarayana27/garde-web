import React, { useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { ContentCard } from '../cards/ContentCard';
import { Content } from '../../types';

interface ContentRowProps {
  title: string;
  items?: Content[];
  fetchFn?: () => Promise<Content[]>;
  queryKey?: string;
}

export function ContentRow({ title, items, fetchFn, queryKey }: ContentRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const { data: fetchedContents = [], isLoading } = useQuery({
    queryKey: [queryKey || title],
    queryFn: fetchFn || (() => Promise.resolve([])),
    enabled: !!fetchFn,
    staleTime: 5 * 60 * 1000,
  });

  const contents = items || fetchedContents;
  const isRowLoading = !!fetchFn && isLoading;

  const scroll = (dir: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === 'left' ? -600 : 600, behavior: 'smooth' });
    }
  };

  return (
    <div className="mb-20">
      <div className="flex items-end justify-between px-4 md:px-8 lg:px-12 mb-8">
        <div className="flex items-center gap-4">
          <div className="h-8 w-1 bg-accent-indigo rounded-full" />
          <h2 className="font-sans text-4xl font-black tracking-tighter text-white uppercase">{title}</h2>
        </div>
        <button className="text-[10px] font-black uppercase tracking-[3px] text-secondary-text hover:text-accent-indigo transition-all">
          View All
        </button>
      </div>
      <div className="relative group">
        <button
          onClick={() => scroll('left')}
          className="absolute left-4 top-[135px] -translate-y-1/2 z-20 p-3 rounded-full bg-background/80 border border-border-custom backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all hover:scale-110 hover:bg-accent-indigo hover:text-white"
        >
          <ChevronLeft size={20} />
        </button>
        <div ref={scrollRef} className="flex gap-8 overflow-x-auto hide-scrollbar px-4 md:px-8 lg:px-12 pb-8 pt-2">
          {isRowLoading
            ? Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-shrink-0 rounded-xl shimmer bg-card border border-border-custom"
                  style={{ width: 180, height: 270 }}
                />
              ))
            : contents.map((content) => (
                <ContentCard key={content.id} content={content} />
              ))}
        </div>
        <button
          onClick={() => scroll('right')}
          className="absolute right-4 top-[135px] -translate-y-1/2 z-20 p-3 rounded-full bg-background/80 border border-border-custom backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all hover:scale-110 hover:bg-accent-indigo hover:text-white"
        >
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}
