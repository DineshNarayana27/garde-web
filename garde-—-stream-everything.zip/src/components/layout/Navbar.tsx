import React, { useState, useEffect, useRef } from 'react';
import { Search, Bell, X, User, Settings, HelpCircle, LogOut, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../../store/useStore';
import { supabase } from '../../lib/supabase';

const NAV_LINKS = [
  { name: 'Home', path: '/' },
  { name: 'Films', path: '/movies' },
  { name: 'Series', path: '/series' },
  { name: 'My Watchlist', path: '/my-list' },
];

const NOTIFICATIONS = [
  { id: 1, text: 'New Film: "The Last Kingdom: Seven Kings Must Die" is now available!', time: '2h ago' },
  { id: 2, text: 'Your subscription has been successfully renewed.', time: '1d ago' },
  { id: 3, text: 'Now Showing: "Sintel" is topping the charts this week.', time: '2d ago' },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  
  const pathname = usePathname();
  const router = useRouter();
  const user = useStore((state) => state.user);
  const setUser = useStore((state) => state.setUser);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfile(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // In a real app, navigate to search results or filter
      console.log('Searching for:', searchQuery);
      setIsSearchOpen(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    router.push('/login');
  };

  const userInitial = user?.email?.charAt(0).toUpperCase() || 'U';

  return (
    <nav
      className={`fixed top-0 z-50 w-full transition-all duration-500 ${
        isScrolled ? 'bg-background/95 backdrop-blur-2xl border-b border-border-custom py-3 shadow-2xl' : 'bg-gradient-to-b from-black/80 to-transparent py-6'
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 md:px-8">
        <div className="flex items-center gap-10">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="h-1.5 w-1.5 rounded-full bg-accent-indigo" />
            <span className="text-xl font-black tracking-[3px] text-white transition-opacity group-hover:opacity-80">
              GARDE
            </span>
          </Link>
          
          <div className="hidden items-center gap-8 md:flex">
            {NAV_LINKS.map((link) => {
              const isActive = pathname === link.path;
              return (
                <Link
                  key={link.path}
                  href={link.path}
                  className={`relative text-[11px] font-bold uppercase tracking-widest transition-all duration-200 hover:text-white ${
                    isActive ? 'text-white' : 'text-secondary-text'
                  }`}
                >
                  {link.name}
                  {isActive && (
                    <motion.div 
                      layoutId="nav-underline"
                      className="absolute -bottom-1 left-0 h-0.5 w-full bg-accent-indigo rounded-full" 
                    />
                  )}
                </Link>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-4 md:gap-6">
          {/* Search */}
          <div ref={searchRef} className="relative flex items-center">
            <AnimatePresence>
              {isSearchOpen && (
                <motion.form
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 240, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  onSubmit={handleSearch}
                  className="absolute right-0 flex items-center overflow-hidden rounded-full bg-surface border border-border-custom"
                >
                  <input
                    autoFocus
                    type="text"
                    placeholder="Search films..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-transparent px-4 py-2 text-xs text-white outline-none placeholder:text-secondary-text"
                  />
                  <button type="button" onClick={() => setIsSearchOpen(false)} className="pr-3 text-secondary-text hover:text-white">
                    <X size={14} />
                  </button>
                </motion.form>
              )}
            </AnimatePresence>
            {!isSearchOpen && (
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="text-secondary-text transition-colors hover:text-white p-2 rounded-full hover:bg-white/5"
              >
                <Search size={18} />
              </button>
            )}
          </div>

          {/* Notifications */}
          <div ref={notificationRef} className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className={`relative text-secondary-text transition-colors hover:text-white p-2 rounded-full hover:bg-white/5 ${showNotifications ? 'text-white bg-white/5' : ''}`}
            >
              <Bell size={18} />
              <span className="absolute top-2 right-2 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-indigo opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-accent-indigo"></span>
              </span>
            </button>

            <AnimatePresence>
              {showNotifications && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-4 w-80 overflow-hidden rounded-2xl border border-border-custom bg-card shadow-2xl"
                >
                  <div className="border-b border-border-custom p-4">
                    <h3 className="text-xs font-bold uppercase tracking-widest">Notifications</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {NOTIFICATIONS.map((n) => (
                      <div key={n.id} className="border-b border-border-custom p-4 last:border-0 hover:bg-white/5 transition-colors cursor-pointer">
                        <p className="text-sm leading-snug">{n.text}</p>
                        <span className="mt-1 block text-[10px] uppercase tracking-wider text-secondary-text">{n.time}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Profile */}
          <div ref={profileRef} className="relative">
            {user ? (
              <button 
                onClick={() => setShowProfile(!showProfile)}
                className="flex items-center gap-2 group"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent-indigo text-xs font-bold text-white shadow-lg shadow-accent-indigo/20 transition-transform group-hover:scale-105">
                  {userInitial}
                </div>
                <ChevronDown size={14} className={`text-secondary-text transition-transform duration-300 ${showProfile ? 'rotate-180' : ''}`} />
              </button>
            ) : (
              <Link
                href="/login"
                className="rounded-lg bg-accent-indigo px-4 py-2 text-xs font-bold text-white transition-transform hover:scale-105"
              >
                Sign In
              </Link>
            )}

            <AnimatePresence>
              {showProfile && user && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-4 w-56 overflow-hidden rounded-2xl border border-border-custom bg-card shadow-2xl"
                >
                  <div className="border-b border-border-custom p-4 bg-white/5">
                    <p className="font-bold truncate text-sm">{user.full_name || user.email}</p>
                    <p className="text-[10px] text-secondary-text truncate">{user.email}</p>
                  </div>
                  <div className="p-2">
                    <Link href="/my-list" className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs text-secondary-text transition-colors hover:bg-white/5 hover:text-white">
                      <User size={16} />
                      My Watchlist
                    </Link>
                    <Link href="/settings" className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs text-secondary-text transition-colors hover:bg-white/5 hover:text-white">
                      <Settings size={16} />
                      Settings
                    </Link>
                    <Link href="/help" className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs text-secondary-text transition-colors hover:bg-white/5 hover:text-white">
                      <HelpCircle size={16} />
                      Help Center
                    </Link>
                    <div className="my-2 h-px bg-border-custom" />
                    <button 
                      onClick={handleSignOut}
                      className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs text-accent-red transition-colors hover:bg-accent-red/10"
                    >
                      <LogOut size={16} />
                      Sign Out
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </nav>
  );
}
