"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../../lib/supabase';
import { useStore } from '../../store/useStore';

export default function LoginPage() {
  const [step, setStep] = useState<1 | 2>(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const router = useRouter();
  const user = useStore((state) => state.user);
  const setUser = useStore((state) => state.setUser);
  
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (user) {
      router.push('/');
    }
  }, [user, router]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { error } = await supabase.auth.signInWithOtp({ email });
      if (error) throw error;
      setStep(2);
    } catch (err: any) {
      setError(err.message || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) value = value[0];
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = otp.join('');
    if (token.length !== 6) return;

    setLoading(true);
    setError(null);

    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: 'email',
      });

      if (error) throw error;

      if (data.user) {
        setUser({
          id: data.user.id,
          email: data.user.email || '',
          full_name: data.user.user_metadata?.full_name || data.user.email?.split('@')[0] || 'User',
          avatar_url: data.user.user_metadata?.avatar_url || `https://picsum.photos/seed/${data.user.id}/200`,
          subscription_plan: 'free',
        });
        router.push('/');
      }
    } catch (err: any) {
      setError(err.message || 'Invalid code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen overflow-hidden bg-background">
      {/* Left Panel - Cinematic Visuals */}
      <div className="relative hidden w-[60%] flex-col justify-center overflow-hidden lg:flex">
        {/* Animated Gradient Background */}
        <div className="animate-gradient-slow absolute inset-0 z-0 opacity-30" />
        
        {/* Noise/Grain Overlay */}
        <div className="noise-overlay opacity-20" />
        
        {/* Content Overlay */}
        <div className="relative z-10 flex h-full flex-col justify-between p-16">
          <div className="flex-1 flex flex-col justify-center items-center text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="font-sans text-5xl font-black leading-tight text-white md:text-7xl uppercase tracking-tighter"
            >
              "Every story <br /> deserves to be seen"
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.6 }}
              className="mt-8 text-xl font-medium tracking-widest text-secondary-text uppercase"
            >
              Join the independent movement
            </motion.p>
          </div>
          
          <div className="mt-auto flex items-center gap-4">
            <div className="h-4 w-4 rounded-full bg-accent-indigo" />
            <h1 className="text-4xl font-black tracking-[8px] text-white">
              GARDE
            </h1>
          </div>
        </div>
      </div>

      {/* Right Panel - Auth Form */}
      <div className="relative z-10 flex w-full flex-col justify-center bg-surface px-8 py-12 lg:w-[40%] lg:border-l lg:border-border-custom lg:px-16">
        <div className="relative z-20 mx-auto w-full max-w-md">
          <div className="mb-16 flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent-indigo" />
            <h1 className="text-xl font-black tracking-[3px] text-white">GARDE</h1>
          </div>

          <AnimatePresence mode="wait">
            {step === 1 ? (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              >
                <h2 className="mb-3 text-4xl font-black text-white tracking-tight">Sign in to Garde</h2>
                <p className="mb-12 text-secondary-text font-medium">Enter your email to join the movement</p>

                <form onSubmit={handleEmailSubmit} className="space-y-8">
                  <div className="group">
                    <label className="mb-3 block text-[10px] font-black uppercase tracking-[2px] text-secondary-text group-focus-within:text-accent-indigo transition-colors">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-xl border border-border-custom bg-background p-5 text-white outline-none transition-all placeholder:text-secondary-text/30 focus:border-accent-indigo focus:ring-1 focus:ring-accent-indigo/20"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="flex w-full items-center justify-center gap-3 rounded-xl bg-accent-indigo py-5 font-black uppercase tracking-[2px] text-white transition-all hover:bg-accent-indigo/90 hover:shadow-2xl hover:shadow-accent-indigo/30 active:scale-[0.98] disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : "Continue"}
                  </button>

                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 text-sm font-medium text-accent-red text-center"
                    >
                      {error}
                    </motion.p>
                  )}
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
              >
                <button
                  onClick={() => setStep(1)}
                  className="mb-10 flex items-center gap-2 text-[10px] font-black uppercase tracking-[2px] text-secondary-text transition-colors hover:text-white"
                >
                  <ArrowLeft size={16} />
                  Back
                </button>

                <h2 className="mb-3 text-4xl font-black text-white tracking-tight">Verify Identity</h2>
                <p className="mb-12 text-secondary-text font-medium">
                  We've sent a 6-digit code to <br />
                  <span className="font-bold text-white">{email}</span>
                </p>

                <form onSubmit={handleVerifyOtp} className="space-y-12">
                  <div className="flex justify-between gap-3">
                    {otp.map((digit, idx) => (
                      <input
                        key={idx}
                        ref={(el) => { otpRefs.current[idx] = el; }}
                        type="text"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpChange(idx, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(idx, e)}
                        className="h-16 w-full rounded-xl border border-border-custom bg-background text-center text-3xl font-black text-white outline-none transition-all focus:border-accent-indigo focus:ring-1 focus:ring-accent-indigo/20"
                      />
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={loading || otp.join('').length !== 6}
                    className="flex w-full items-center justify-center gap-3 rounded-xl bg-accent-indigo py-5 font-black uppercase tracking-[2px] text-white transition-all hover:bg-accent-indigo/90 hover:shadow-2xl hover:shadow-accent-indigo/30 active:scale-[0.98] disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : "Verify & Sign In"}
                  </button>

                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 text-sm font-medium text-accent-red text-center"
                    >
                      {error}
                    </motion.p>
                  )}
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <p className="mt-16 text-center text-[10px] font-medium leading-relaxed text-secondary-text/40 uppercase tracking-widest">
            By continuing you agree to our <br />
            <span className="underline cursor-pointer hover:text-secondary-text">Terms of Service</span> and <span className="underline cursor-pointer hover:text-secondary-text">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}
