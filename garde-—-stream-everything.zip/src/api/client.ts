/**
 * Base API Client (Gateway)
 * In a real microservice architecture, this would handle:
 * - Auth headers
 * - Base URL configuration
 * - Error handling/interceptors
 * - Request/Response logging
 */
export const apiClient = {
  get: async <T>(endpoint: string): Promise<T> => {
    console.log(`[Gateway] Fetching from: ${endpoint}`);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // In a real app:
    // const response = await fetch(`${process.env.API_BASE_URL}${endpoint}`);
    // return response.json();
    
    throw new Error("API Client requires implementation with real endpoints");
  }
};
